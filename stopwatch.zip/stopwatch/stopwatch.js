//creating a variable for true or false//
var isStop = true 
//creating three variables for storing value of s ,min, hr//
var s = 0;
var min = 0;
var hr = 0;

//This is a start function//
function start()
{

    
    if(isStop == true)
    {
        isStop=false;
        timer();

    }

}
//this is a timer function//
function timer()
{
   

  if ( isStop == false)
  {
    s=parseInt(s);
    min=parseInt(min);
    hr=parseInt(hr);

 

   s++;
   if(s==60)
   {
    s=0;
    min++;
   }
   if(min==60)
   {
    min=0;
    hr++;
   }
   if(s<10)
   {

    s = "0"+s;
   }

if(min<10)
{

 min = "0"+min;
}


if(hr<10)
{

 hr= "0"+hr;
}
   
  //getelementById of DOM for getting ID of innerHTML//
   document.getElementById("stopwatch").innerHTML = hr + ":" + min +":"+ s;
   setTimeout("timer()",1000);
}
    
}

// stop function//
  function stop()
  {
    isStop=true;

  
  }
//reset function//
function reset()
{
    isStop=true;
    s=0;
    min=0;
    hr=0;
    stopwatch.innerHTML= "00:00:00";
}



